// Alternar entre telas de login e cadastro
const btnSignin = document.querySelector("#signin");
const btnSignup = document.querySelector("#signup");
const body = document.querySelector("body");

btnSignin.addEventListener("click", () => body.className = "sign-in-js");
btnSignup.addEventListener("click", () => body.className = "sign-up-js");

// Função de envio genérica de requisições
async function sendRequest(url, data) {
    try {
        const response = await fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams(data)
        });
        return await response.json();
    } catch (err) {
        console.error("Erro:", err);
        alert("Erro ao conectar ao servidor.");
    }
}

// Cadastro
document.getElementById('registerForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;
    const senha = document.getElementById('password').value;

    const data = await sendRequest('register.php', { nome, email, senha });
    alert(data?.message || "Erro ao cadastrar.");
    if (data?.success) {
        window.location.href = 'telainicial.html'; // Redireciona após o cadastro
    }
});

// Login
document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const senha = document.getElementById('loginPassword').value;

    const data = await sendRequest('login.php', { email, senha });
    alert(data?.message || "Erro ao realizar login.");
    if (data?.success) {
        window.location.href = 'telainicial.html'; // Redireciona após o login bem-sucedido
    }
});
