// Concluir tarefa
elseif ($method === 'PUT' && isset($_GET['complete'])) {
    $data = json_decode(file_get_contents('php://input'), true);
    $stmt = $conn->prepare("UPDATE tasks SET status = 'completed' WHERE id = ?");
    $stmt->bind_param("i", $data['id']);
    $stmt->execute();
    echo json_encode(["completed" => $stmt->affected_rows]);
}

// Obter histórico de tarefas
elseif ($method === 'GET' && isset($_GET['history'])) {
    $result = $conn->query("SELECT * FROM tasks WHERE status IN ('completed', 'deleted')");
    $history = [];
    while ($row = $result->fetch_assoc()) {
        $history[] = $row;
    }
    echo json_encode($history);
}
