async function fetchHistory() {
    const res = await fetch(`${API_URL}?history=true`);
    const history = await res.json();
    renderHistory(history);
  }
  function renderHistory(history) {
    const historyList = document.getElementById('historyList');
    historyList.innerHTML = '';
    if (history.length === 0) {
      historyList.innerHTML = '<p>Sem tarefas no histórico.</p>';
      return;
    }
    history.forEach((task) => {
      const taskEl = document.createElement('div');
      taskEl.className = 'history-item';
      taskEl.innerHTML = `
        <h3>${task.title}</h3>
        <p>${task.description}</p>
        <p>Prazo: ${task.deadline}</p>
        <p>Status: ${task.status}</p>
      `;
      historyList.appendChild(taskEl);
    });
  }
  async function completeTask(id) {
    await fetch(`${API_URL}?complete=true`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id }),
    });
    fetchTasks();
    fetchHistory();
  }
  function renderTasks(tasks) {
    taskList.innerHTML = '';
    tasks.forEach((task) => {
      const taskEl = document.createElement('div');
      taskEl.className = 'task-item';
      taskEl.innerHTML = `
        <h3>${task.title}</h3>
        <p>${task.description}</p>
        <p>Prazo: ${task.deadline}</p>
        <p>Prioridade: ${task.priority}</p>
        <button onclick="completeTask(${task.id})">Concluir</button>
        <button onclick="deleteTask(${task.id})">Excluir</button>
      `;
      taskList.appendChild(taskEl);
    });
  }
  fetchHistory();
  