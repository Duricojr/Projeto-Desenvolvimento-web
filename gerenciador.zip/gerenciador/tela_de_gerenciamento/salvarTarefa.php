<?php
$conn = new mysqli('localhost', 'root', '', 'bdtarefa');
if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

$data = json_decode(file_get_contents("php://input"), true);

$descricao = $data['descricao'];
$prazo = $data['prazo'];
$prioridade = $data['prioridade'];
$status = 'pendente';

$sql = "INSERT INTO tarefa (descricao, prazo, prioridade, status) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $descricao, $prazo, $prioridade, $status);

if ($stmt->execute()) {
    echo json_encode(['message' => 'Tarefa criada com sucesso!']);
} else {
    echo json_encode(['message' => 'Erro ao criar a tarefa.']);
}

$stmt->close();
$conn->close();
?>
