<?php
// Conectar ao banco de dados
$conn = new mysqli("localhost", "root", "", "bdtarefa");

// Verificar a conexão
if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

// Receber o ID da tarefa
$idTarefa = $_GET['idtarefa']; // ID da tarefa

// Atualizar o status da tarefa para 'concluída'
$query = "UPDATE tarefa SET status = 'concluída' WHERE idtarefa = $idTarefa";

// Executar a consulta
if ($conn->query($query) === TRUE) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false, "message" => "Erro ao atualizar o status"]);
}

$conn->close();
?>
