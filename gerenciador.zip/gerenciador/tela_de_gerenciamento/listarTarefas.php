<?php
// Definir o cabeçalho para JSON
header('Content-Type: application/json');

// Conectar ao banco de dados
$servername = "localhost";
$username = "root";  // Usuário padrão do XAMPP
$password = "";      // Senha padrão do XAMPP
$dbname = "bdtarefa"; // Nome do banco de dados

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar a conexão
if ($conn->connect_error) {
    die(json_encode(['message' => 'Erro de conexão: ' . $conn->connect_error]));
}

// Obter os parâmetros de filtro
$status = isset($_GET['status']) ? $_GET['status'] : ''; // "pendente" ou "concluida"
$prioridade = isset($_GET['prioridade']) ? $_GET['prioridade'] : '';

// Construir a consulta SQL com base no filtro
$sql = "SELECT idtarefa, descricao, prazo, prioridade, status FROM tarefa";

// Adicionar condições baseadas nos filtros
$conditions = [];
if ($status) {
    $status = $conn->real_escape_string($status); // Evitar injeção de SQL
    $conditions[] = "status = '$status'";
}

if ($prioridade) {
    $prioridade = $conn->real_escape_string($prioridade); // Evitar injeção de SQL
    $conditions[] = "prioridade = '$prioridade'";
}

// Se houver condições, adicioná-las à consulta
if (count($conditions) > 0) {
    $sql .= " WHERE " . implode(" AND ", $conditions);
}

// Executar a consulta
$result = $conn->query($sql);

$tasks = [];

// Verificar se há resultados
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $tasks[] = $row;
    }
}

// Retornar as tarefas em formato JSON
echo json_encode($tasks);

// Fechar a conexão
$conn->close();
?>
