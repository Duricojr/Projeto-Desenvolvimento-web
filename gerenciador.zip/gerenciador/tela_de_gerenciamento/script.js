// Variáveis para rastrear o ID da tarefa em edição
let editingTaskId = null;

// Abrir e fechar o modal
const taskModal = document.getElementById("taskModal");
const newTaskBtn = document.getElementById("newTaskBtn");
const cancelBtn = document.getElementById("cancelBtn");
const taskForm = document.getElementById("taskForm");

// Botão para abrir o modal de nova tarefa
newTaskBtn.addEventListener("click", () => {
    editingTaskId = null; // Resetar edição
    taskModal.style.display = "block";
    document.getElementById("modalTitle").textContent = "Nova Tarefa";
    taskForm.reset(); // Limpar formulário
});

// Botão para cancelar a criação ou edição da tarefa
cancelBtn.addEventListener("click", () => {
    taskModal.style.display = "none";
});

// Submeter tarefa (nova ou edição)
taskForm.addEventListener("submit", (e) => {
    e.preventDefault();

    // Dados da tarefa
    const taskData = {
        descricao: document.getElementById("taskDescription").value,
        prazo: document.getElementById("taskDeadline").value,
        prioridade: document.getElementById("taskPriority").value,
    };

    if (editingTaskId) {
        // Editar tarefa existente
        editTask(editingTaskId, taskData);
    } else {
        // Criar nova tarefa
        createTask(taskData);
    }

    taskModal.style.display = "none"; // Fechar o modal após a ação
});

// Função para carregar tarefas
function loadTasks() {
    // Simulação de tarefas carregadas (você pode substituir por dados dinâmicos)
    const tasks = [
        { id: 1, descricao: "Tarefa 1", prazo: "2024-12-01", prioridade: "alta" },
        { id: 2, descricao: "Tarefa 2", prazo: "2024-12-02", prioridade: "média" },
    ];

    const taskList = document.getElementById("taskList");
    taskList.innerHTML = tasks
        .map(
            (task) => `
                <div class="task" id="task-${task.id}">
                    <h3>${task.descricao}</h3>
                    <p><strong>Prazo:</strong> ${task.prazo}</p>
                    <p><strong>Prioridade:</strong> ${task.prioridade}</p>
                    <button onclick="deleteTask(${task.id})">Excluir</button>
                </div>`
        )
        .join("");
}

// Função para criar nova tarefa
function createTask(taskData) {
    const taskList = document.getElementById("taskList");
    const newTask = document.createElement("div");
    newTask.classList.add("task");
    newTask.id = "task-" + Date.now();
    newTask.innerHTML = `
        <h3>${taskData.descricao}</h3>
        <p><strong>Prazo:</strong> ${taskData.prazo}</p>
        <p><strong>Prioridade:</strong> ${taskData.prioridade}</p>
        <button onclick="deleteTask(${newTask.id})">Excluir</button>
    `;
    taskList.appendChild(newTask);
}

// Função para excluir tarefa
function deleteTask(taskId) {
    const taskElement = document.getElementById("task-" + taskId);
    if (taskElement) {
        taskElement.remove(); // Remove o elemento da página
    }
}

// Carregar as tarefas ao iniciar
document.addEventListener("DOMContentLoaded", loadTasks);
