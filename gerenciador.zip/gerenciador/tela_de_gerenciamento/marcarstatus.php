<?php
// Conectar ao banco de dados
require_once 'conexao.php'; // Certifique-se de ter uma conexão com o banco

// Verificar se o ID da tarefa foi fornecido
if (isset($_GET['idtarefa'])) {
    $idtarefa = $_GET['idtarefa'];

    // Buscar o status atual da tarefa
    $query = "SELECT status FROM tarefa WHERE idtarefa = '$idtarefa'";
    $result = mysqli_query($conn, $query);
    $task = mysqli_fetch_assoc($result);

    if ($task) {
        // Alternar o status da tarefa
        $newStatus = ($task['status'] === 'pendente') ? 'concluída' : 'pendente';

        // Atualizar o status da tarefa no banco de dados
        $updateQuery = "UPDATE tarefa SET status = '$newStatus' WHERE idtarefa = '$idtarefa'";
        if (mysqli_query($conn, $updateQuery)) {
            echo json_encode(["status" => "sucesso", "newStatus" => $newStatus]);
        } else {
            echo json_encode(["status" => "erro", "message" => "Erro ao atualizar status"]);
        }
    } else {
        echo json_encode(["status" => "erro", "message" => "Tarefa não encontrada"]);
    }
}
?>
