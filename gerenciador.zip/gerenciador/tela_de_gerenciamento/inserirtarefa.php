<?php
// Conectar ao banco de dados
require_once 'conexao.php'; // Certifique-se de ter uma conexão com o banco

// Verificar se os dados foram recebidos via POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $descricao = mysqli_real_escape_string($conn, $_POST['descricao']);
    $prazo = mysqli_real_escape_string($conn, $_POST['prazo']);
    $prioridade = mysqli_real_escape_string($conn, $_POST['prioridade']);
    $status = 'pendente';  // Status inicial como 'pendente'

    // Inserir a nova tarefa no banco de dados
    $query = "INSERT INTO tarefa (descricao, prazo, prioridade, status) 
              VALUES ('$descricao', '$prazo', '$prioridade', '$status')";
    
    if (mysqli_query($conn, $query)) {
        echo "Tarefa inserida com sucesso!";
    } else {
        echo "Erro ao inserir tarefa: " . mysqli_error($conn);
    }
}
?>
