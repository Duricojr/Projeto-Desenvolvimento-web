<?php
include 'conexao.php';

$idtarefa = $_POST['idtarefa'] ?? null;
$data = json_decode(file_get_contents('php://input'), true);

if (!$idtarefa || !$data) {
    echo json_encode(['message' => 'Dados insuficientes']);
    exit;
}

$descricao = $data['descricao'];
$prazo = $data['prazo'];
$prioridade = $data['prioridade'];

$sqlUpdate = "UPDATE tarefa SET descricao = ?, prazo = ?, prioridade = ? WHERE idtarefa = ?";
$stmt = $conn->prepare($sqlUpdate);
$stmt->bind_param("sssi", $descricao, $prazo, $prioridade, $idtarefa);

if ($stmt->execute()) {
    echo json_encode(['message' => 'Tarefa atualizada com sucesso']);
} else {
    echo json_encode(['message' => 'Erro ao atualizar a tarefa']);
}
?>
