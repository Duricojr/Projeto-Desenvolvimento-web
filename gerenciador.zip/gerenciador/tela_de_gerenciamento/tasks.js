// Definir o ID da pessoa (substitua conforme necessário)
const pessoaId = 1;

// Função para carregar as tarefas
function loadTasks(priority = "") {
  // Montar a URL de requisição para o PHP
  let url = `listarTarefas.php?pessoa_idpessoa=${pessoaId}`;
  if (priority) url += `&prioridade=${priority}`;

  // Realizar a requisição para o servidor
  fetch(url)
    .then((res) => res.json()) // Processar a resposta como JSON
    .then((tasks) => {
      const taskList = document.getElementById("taskList");
      taskList.innerHTML = ""; // Limpar a lista de tarefas

      // Verificar se há tarefas
      if (tasks.length > 0) {
        tasks.forEach((task) => {
          // Criar o HTML para cada tarefa
          const taskElement = document.createElement("div");
          taskElement.classList.add("task");
          taskElement.id = `task-${task.idtarefa}`;
          taskElement.innerHTML = `
            <h3>${task.descricao}</h3>
            <p><strong>Prazo:</strong> ${task.prazo}</p>
            <p><strong>Prioridade:</strong> ${task.prioridade}</p>
            <div class="status">
              <div class="status-indicator ${task.status === 'concluída' ? 'completed' : 'pending'}"></div>
              <span>${task.status === 'concluída' ? 'Concluída' : 'Não Concluída'}</span>
            </div>
          `;
          taskList.appendChild(taskElement); // Adicionar a tarefa à lista
        });
      } else {
        taskList.innerHTML = "<p>Não há tarefas para exibir.</p>"; // Exibir mensagem se não houver tarefas
      }
    })
    .catch((err) => console.error("Erro ao carregar tarefas:", err)); // Exibir erros, se houver
}

// Função para alternar o status da tarefa entre concluída e não concluída
function toggleCompletion(taskId, button) {
  // Enviar a requisição para alternar o status da tarefa
  fetch(`alternarStatus.php?idtarefa=${taskId}`, { method: "POST" })
    .then((res) => res.json())
    .then((task) => {
      const taskDiv = button.closest('.task');
      const taskTitle = taskDiv.querySelector('h3');
      const statusIndicator = taskDiv.querySelector('.status-indicator');
      const statusSpan = taskDiv.querySelector('.status span');

      // Alterar o título e o botão com base no status
      if (task.status === 'concluída') {
        taskTitle.textContent = `Concluída: ${task.descricao}`;
        button.textContent = 'Marcar como Não Concluída';
        button.style.backgroundColor = "green"; // Tornar o botão verde
        button.style.color = "white"; // Texto branco
        statusIndicator.classList.remove('pending');
        statusIndicator.classList.add('completed');
        statusSpan.textContent = 'Concluída';
      } else {
        taskTitle.textContent = task.descricao;
        button.textContent = 'Marcar como Concluída';
        button.style.backgroundColor = ""; // Resetar o botão
        button.style.color = ""; // Resetar o texto
        statusIndicator.classList.remove('completed');
        statusIndicator.classList.add('pending');
        statusSpan.textContent = 'Não Concluída';
      }
    })
    .catch((err) => console.error("Erro ao alternar o status:", err));
}

// Adicionar o evento de filtro de prioridade
document.getElementById("filterPriority").addEventListener("change", (e) => {
  loadTasks(e.target.value); // Carregar as tarefas com o filtro selecionado
});

// Carregar as tarefas ao carregar a página
document.addEventListener("DOMContentLoaded", () => loadTasks());

