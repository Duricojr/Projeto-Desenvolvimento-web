<?php
// Verifica se a tarefa ID foi enviada
if (isset($_GET['idtarefa'])) {
    $idtarefa = $_GET['idtarefa'];

    // Conexão com o banco de dados
    $conn = new mysqli('localhost', 'root', '', 'bdtarefa'); // Substitua com suas credenciais reais
    if ($conn->connect_error) {
        die("Erro de conexão: " . $conn->connect_error);
    }

    // SQL para excluir a tarefa
    $sql = "DELETE FROM tarefa WHERE idtarefa = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $idtarefa); // "i" significa inteiro
    $result = $stmt->execute();

    if ($result) {
        echo json_encode(['message' => 'Tarefa excluída com sucesso!']);
    } else {
        echo json_encode(['message' => 'Erro ao excluir tarefa.']);
    }

    // Fechar a conexão
    $stmt->close();
    $conn->close();
} else {
    echo json_encode(['message' => 'ID da tarefa não especificado.']);
}
?>
